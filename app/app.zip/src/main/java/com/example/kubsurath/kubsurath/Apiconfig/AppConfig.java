package com.example.kubsurath.kubsurath.Apiconfig;

/**
 * Created by dinesh on 06-Apr-15.
 */
public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://andlog.jobstracer.com/index.php";

    // Server user register url
    public static String URL_REGISTER = "http://andlog.jobstracer.com/index.php";
}
