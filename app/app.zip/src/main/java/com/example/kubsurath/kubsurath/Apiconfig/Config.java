package com.example.kubsurath.kubsurath.Apiconfig;

/**
 * Created by dinesh on 20-Apr-15.
 */
public class Config {
    // File upload url (replace the ip with your server address)
    public static final String FILE_UPLOAD_URL = "http://andlog.jobstracer.com/fileUpload.php";

    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "";
}