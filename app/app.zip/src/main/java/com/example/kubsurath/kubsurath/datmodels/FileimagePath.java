package com.example.kubsurath.kubsurath.datmodels;

/**
 * Created by dinesh on 22-Apr-15.
 */
public class FileimagePath {

    private String imagefilepath;

    public FileimagePath (){}
    public FileimagePath(String imagefilepath) {
        this.imagefilepath = imagefilepath;
    }

    public String getImagefilepath() {
        return imagefilepath;
    }

    public void setImagefilepath(String imagefilepath) {
        this.imagefilepath = imagefilepath;
    }
}
